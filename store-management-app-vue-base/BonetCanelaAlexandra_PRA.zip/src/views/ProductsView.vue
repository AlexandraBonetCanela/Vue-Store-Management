<script>
export default {
  name: "ProductsView"
}
</script>

<template>
  <h1 class="h1">Welcome to Products!</h1>
</template>

<style scoped>

</style>